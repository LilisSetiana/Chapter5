package two.example.latihan20april

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*
import two.example.latihan20april.Adapter.AdapterFilm

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        viewModel.getLiveRegister().observe(this, Observer {
            when {
                username.isEmpty() -> {
                    Toast.makeText(this, "Username Harus Di Isi", Toast.LENGTH_LONG).show()
                }
                email.isEmpty() -> {
                    Toast.makeText(this, "Email Harus Di Isi", Toast.LENGTH_LONG).show()
                }
            }
        })
    }
}
