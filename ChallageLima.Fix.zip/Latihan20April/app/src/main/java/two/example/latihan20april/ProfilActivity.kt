package two.example.latihan20april

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

class ProfilActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

            .setPositiveButton("YA") { dialogInterface: DialogInterface, i: Int ->
                Toast.makeText(this, "Berhasil Update", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, HomeActivity::class.java))

            }
            .setNegativeButton("TIDAK") { dialogInterface: DialogInterface, i: Int ->
                dialogInterface.dismiss()
                private fun logout(){
                    btn_logout.setOnClickListener {
                        AlertDialog.Builder(this) val sharedPrefs = sharedPreferences.edit()
                        sharedPrefs.clear()
                        sharedPrefs.apply()

                        startActivity(Intent(this, LoginActivity::class.java))
                        finish()
                        startActivity(Intent(this, SplashScreenActivity::class.java))
                    }
                        .setNegativeButton("TIDAK"){ dialogInterface: DialogInterface, i: Int ->
                            dialogInterface.dismiss()
            }
    }
}