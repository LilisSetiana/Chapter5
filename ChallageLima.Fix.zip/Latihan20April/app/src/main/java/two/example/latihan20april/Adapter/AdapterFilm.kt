package two.example.latihan20april.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.*
import kotlinx.android.synthetic.main.item_film.view.*
import two.example.latihan20april.R
import two.example.latihan20april.model.GetFilmResponseItem

class AdapterFilm(private val datafilm: List<GetFilmResponseItem>) : RecyclerView.Adapter<AdapterFilm.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapterFilm.ViewHolder {
        val itemview = LayoutInflater.from(parent.context).inflate(R.layout.item_film, parent, false)
        return ViewHolder(itemview)
    }

    override fun onBindViewHolder(holder: AdapterFilm.ViewHolder, position: Int) {
        holder.itemView.nama_film_tv.text = datafilm[position].title
        holder.itemView.tanggal_film.text = datafilm[position].id
        holder.itemView.sutradara_film.text = datafilm[position].createdAt

    }

    override fun getItemCount(): Int {
        return datafilm.size
    }

}