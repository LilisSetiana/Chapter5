package two.example.latihan20april.model


import com.google.gson.annotations.SerializedName

class ResponseUser : ArrayList<ResponseUserItem>()