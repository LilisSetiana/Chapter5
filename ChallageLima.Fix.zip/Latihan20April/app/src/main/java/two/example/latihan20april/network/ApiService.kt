package two.example.latihan20april.network

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.POST
import two.example.latihan20april.model.GetFilmResponseItem

interface ApiService {
    @GET("apifilm.php")
    fun getFilm() : Call<List<GetFilmResponseItem>>






}