package two.example.latihan20april

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_register.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)


                if (getSharedPreferences("LOGIN", Context.MODE_PRIVATE).contains("EMAIL") &&
                    getSharedPreferences("LOGIN", Context.MODE_PRIVATE).contains("PASSWORD")
                ) {
                    getSharedPreferences("LOGIN", Context.MODE_PRIVATE).contains("PASSWORD")) {
                        startActivity(Intent(this, HomeActivity::class.java))

                    }


                    daftar()
                    login()
                }

            }

}

