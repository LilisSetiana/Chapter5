package two.example.latihan20april.model


import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class ResponseLogin(
    @SerializedName("address")
    val address: Any,
    @SerializedName("complete_name")
    val completeName: Any,
    @SerializedName("dateofbirth")
    val dateofbirth: Any,
    @SerializedName("email")
    val email: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("password")
    val password: String,
    @SerializedName("username")
    val username: String
): Parcelable